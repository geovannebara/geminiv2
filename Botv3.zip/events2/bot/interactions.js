const { InteractionType } = require("discord.js");


module.exports = {
    name:"interactionCreate",
    run:async(interaction, client) => {

        if(interaction.type === InteractionType.ApplicationCommand){

            const cmd = client.slashCommands.get(interaction.commandName);
      
            if (!cmd) return interaction.reply(`Error`);
      
            interaction["member"] = interaction.guild.members.cache.get(interaction.user.id);
      
            cmd.run(client, interaction)
      
         };
          
         if(interaction.isAutocomplete()) {
            const command = client.slashCommands.get(interaction.commandName)
            if(!command) {
              return;
            }
            
        
            try{
              await command.autocomplete(interaction);
            }catch(err){return;}
          }; 
    }
}